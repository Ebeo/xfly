static const GUID GuidInterfaceList[] =
	{
		// GUID_DEVINTERFACE_USB_DEVICE
		{0xa5dcbf10, 0x6530, 0x11d2, {0x90, 0x1f, 0x00, 0xc0, 0x4f, 0xb9, 0x51, 0xed}},		// Virtual COM port
		// GUID_DEVINTERFACE_DISK
		//{0x53f56307, 0xb6bf, 0x11d0, {0x94, 0xf2, 0x00, 0xa0, 0xc9, 0x1e, 0xfb, 0x8b}},
		// GUID_DEVINTERFACE_HID
		//{0x4d1e55b2, 0xf16f, 0x11Cf, {0x88, 0xcb, 0x00, 0x11, 0x11, 0x00, 0x00, 0x30}},
		// GUID_NDIS_LAN_CLASS
		//{0xad498944, 0x762f, 0x11d0, {0x8d, 0xcb, 0x00, 0xc0, 0x4f, 0xc3, 0x35, 0x8c}},
		//{0x219d0508, 0x57a8, 0x4ff5, {0x97, 0xa1, 0xbd, 0x86, 0x58, 0x7c, 0x6c, 0x7e}},
		// GUID_DEVINTERFACE_COMPORT
		{0x86e0d1e0, 0x8089, 0x11d0, {0x9c, 0xe4, 0x08, 0x00, 0x3e, 0x30, 0x1f, 0x73}},		// USB to COM
	};

struct LISTPORTS_PORTINFO
{
	LPCTSTR lpPortName;     /* "COM1", etc. */
	LPCTSTR lpFriendlyName; /* Suitable to describe the port, as for  */
							/* instance "Infrared serial port (COM4)" */
	LPCTSTR lpTechnology;   /* "BIOS","INFRARED","USB", etc.          */
	LISTPORTS_PORTINFO* next;
};

class CSerialScan
{
public:
	CSerialScan();
	virtual ~CSerialScan();
	void DeviceNotify(HWND hWnd);
	LISTPORTS_PORTINFO* GetListPorts();

private:
	BOOL ListPorts();
	BOOL Win9xListPorts();
	BOOL WinNT40ListPorts();
	BOOL Win2000ListPorts();
	BOOL ScanEnumTree(LPCTSTR lpEnumPath);
	LONG OpenSubKeyByIndex(HKEY hKey, DWORD dwIndex, REGSAM samDesired, PHKEY phkResult, LPTSTR* lppSubKeyName);
	LONG QueryStringValue(HKEY hKey, LPCTSTR lpValueName, LPTSTR* lppStringValue);
	// thiet lap danh sach com list, them 1 cong COM vao cuoi danh sach
	void CreateComToList(LISTPORTS_PORTINFO aCom);
	// bo sung cac thong tin cua cong COM trong list
	void AddComToList(LISTPORTS_PORTINFO aCom);
	void RemoveComList();

	LISTPORTS_PORTINFO* ListAvailableCom;// = NULL;
	TCHAR szComStr[64 * 128];//MAX_LOADSTRING];

protected:

	LISTPORTS_PORTINFO* ListAvailableComRoot;// = NULL;
};
