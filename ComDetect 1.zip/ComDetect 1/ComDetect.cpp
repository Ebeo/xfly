// ComDetect.cpp : Defines the entry point for the application.
//

#define STRICT

#include "stdafx.h"
#include "resource.h"
#include <dbt.h>
#include "SerialEx.h"
#include "SerialScan.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// The title bar text

// Foward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

HWND hWnd, hWndList, hWndEditSend, hWndEditReceiver, hwndButtonCon, hwndButtonDis;

CSerialScan seriallist;	// danh sach ten cac cong COM
CSerialEx serialobj;	// doi tuong doc/ghi cong COM
LISTPORTS_PORTINFO *ListCom;

void UpdateListBox()
{
	TCHAR sComName[128];

	ListCom = seriallist.GetListPorts();
	LISTPORTS_PORTINFO *tmp = ListCom;

	SendMessage(hWndList, LB_RESETCONTENT, NULL, NULL);
	while (tmp != NULL)
	{
		strcpy(sComName, tmp->lpFriendlyName);
		SendMessage(hWndList, LB_ADDSTRING, NULL, (LPARAM)sComName);
		tmp = tmp->next;
	}
}

// lay so hieu cong COM trong listbox
// vi du chon cong COM20 tra ve 20, neu khong chon tr ve gia tri -1
int GetListBoxSelect()
{
	int index = (int) SendMessage(hWndList, LB_GETCURSEL, 0, 0);		// lay item duoc chon
	if (index >= 0)
	{
		int length = SendMessage (hWndList, LB_GETTEXTLEN, index, 0) + 1;	// lay do dai chuoi cua item da chon
		TCHAR *pVarName;
		pVarName =(char*) malloc (length * sizeof (TCHAR));
		SendMessage(hWndList, LB_GETTEXT, index, (LPARAM)pVarName);

		LISTPORTS_PORTINFO *tmp = ListCom;
		while (tmp && _strnicmp(tmp->lpFriendlyName, pVarName, strlen(pVarName)))
		{
			tmp = tmp->next;
		}

		if (tmp)
		{
			TCHAR PortName[6];
			strcpy(PortName, tmp->lpPortName);
			_strnset(PortName, ' ', 3 );		// ex: COM20 -> "   20" to convert
			index = atoi(PortName);
		}
	}
	return index;
}

void Connect()
{
	TCHAR comname[16] = "\\\\.\\COM";
	TCHAR buff[4];
	int comselect = GetListBoxSelect();
	if (comselect < 0)
	{
		MessageBox(hWnd, "Select COM", "PCom", MB_OK);
		return;
	}
	itoa(comselect, buff, 10);
	strcat(comname, buff);
	long lLastError = serialobj.Open(comname, hWnd);
	if (lLastError != ERROR_SUCCESS)
	{
		MessageBox(hWnd, "Error COM", "PCom", MB_OK);
		return;
	}
	serialobj.Setup(CSerial::EBaud115200, CSerial::EData8, CSerial::EParNone, CSerial::EStop1);
	serialobj.SetupHandshaking(CSerial::EHandshakeHardware);
}

void Disconnect()
{
	serialobj.StopListener(INFINITE);
	serialobj.Close();
}

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_COMDETECT, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_COMDETECT);

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	// Close the port again
	serialobj.Close();

	return 0;//msg.wParam;
}

ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_COMDETECT);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= (LPCSTR)IDC_COMDETECT;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	hInst = hInstance; // Store instance handle in our global variable

	hWnd = CreateWindow(szWindowClass, szTitle, WS_CAPTION | WS_MINIMIZEBOX | WS_SYSMENU | WS_VISIBLE,
		CW_USEDEFAULT, CW_USEDEFAULT, 500, 430, NULL, NULL, hInstance, NULL);

	if (!hWnd)
	{
		return FALSE;
	}

	hWndList = CreateWindowEx(WS_EX_CLIENTEDGE, TEXT("LISTBOX"), TEXT(""), 
		WS_CHILD|WS_VSCROLL|WS_VISIBLE|LBS_NOTIFY|LBS_HASSTRINGS|LBS_SORT|LBS_DISABLENOSCROLL|LBS_NOINTEGRALHEIGHT, 10, 20, 470, 120, hWnd, NULL, NULL, NULL);

	hWndEditSend = CreateWindowEx(WS_EX_CLIENTEDGE, TEXT("EDIT"), TEXT(""), 
		WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_READONLY, 10, 200, 470, 50, hWnd, NULL, NULL, NULL);

	hWndEditReceiver = CreateWindowEx(WS_EX_CLIENTEDGE, TEXT("EDIT"), TEXT(""), 
		WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_READONLY, 10, 270, 470, 80, hWnd, NULL, NULL, NULL);

	hwndButtonCon = CreateWindow("BUTTON", "Connect", 
		WS_VISIBLE | WS_CHILD /*| BS_FLAT | BS_OWNERDRAW*/, 
		100, 150, 100, 30, hWnd, (HMENU)ID_BTCN, (HINSTANCE) GetWindowLong(hWnd, GWL_HINSTANCE), NULL);      // pointer not needed 

	hwndButtonDis = CreateWindow("BUTTON", "Disconn", 
		WS_VISIBLE | WS_CHILD /*| BS_FLAT | BS_OWNERDRAW*/, 
		300, 150, 100, 30, hWnd, (HMENU)ID_BTDS, (HINSTANCE) GetWindowLong(hWnd, GWL_HINSTANCE), NULL);      // pointer not needed 


	seriallist.DeviceNotify(hWnd);
	UpdateListBox();

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	return TRUE;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;
	TCHAR szHello[MAX_LOADSTRING];
	LoadString(hInst, IDS_HELLO, szHello, MAX_LOADSTRING);

	if (message == CSerialEx::mg_nDefaultComMsg)
	{
		// A serial message occurred
		const CSerialEx::EEvent eEvent = CSerialEx::EEvent(LOWORD(wParam));
		const CSerialEx::EError eError = CSerialEx::EError(HIWORD(wParam));

		switch (eEvent)
		{
			case CSerialEx::EEventRecv:
				// TODO: Read data from the port
				DWORD dwRead;
				char szData[101];
				const int nBuflen = sizeof(szData)-1;

				// Obtain the data from the serial port
				do
				{
					serialobj.Read(szData,nBuflen,&dwRead);
					szData[dwRead] = '\0';

					// Scan the string for unwanted characters
					for (DWORD dwChar=0; dwChar<dwRead; dwChar++)
					{
						if (!isprint(szData[dwChar]) && !isspace(szData[dwChar]))
						{
							szData[dwChar] = '.';
						}
					}

#ifdef _UNICODE
					// Convert the ANSI data to Unicode
					LPTSTR lpszData = LPTSTR(_alloca((dwRead+1)*sizeof(TCHAR)));
					if (!::MultiByteToWideChar(CP_ACP, 0, szData, -1, lpszData, dwRead+1))
						return 0;

					//DisplayData(lpszData);	// Display the fetched string
#else
					//DisplayData(szData);		// Display the fetched string
					SetWindowText(hWndEditReceiver, szData);
#endif
				} while (dwRead == nBuflen);
				break;
		}
		// Return successful
		return 0;
	} 

	switch (message)
	{
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			// Parse the menu selections:
			switch (wmId)
			{
				case IDM_ABOUT:
					DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
				   break;
				case IDM_EXIT:
				   DestroyWindow(hWnd);
				   break;
				// connect button
				case ID_BTCN:
					Disconnect();
					Connect();
					break;
				// disconnect button
				case ID_BTDS:
					Disconnect();
					break;
				default:
				   return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;
		case WM_DEVICECHANGE:
			{
				PDEV_BROADCAST_HDR pHdr = (PDEV_BROADCAST_HDR) lParam;
				switch (wParam)
				{
					case DBT_DEVICEARRIVAL: // 32768
						UpdateListBox();
						break;
					case DBT_DEVICEREMOVECOMPLETE: // 32772
						UpdateListBox();
						break;
				}
			}
			break;
		case WM_PAINT:
			hdc = BeginPaint(hWnd, &ps);
			// TODO: Add any drawing code here...
			RECT rt;
			GetClientRect(hWnd, &rt);
			DrawText(hdc, szHello, strlen(szHello), &rt, DT_CENTER);
			EndPaint(hWnd, &ps);
			break;
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

// Mesage handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
    return FALSE;
}
